1. Install Node.js
2. Open the CLI
3. Run "cd to/the/directory/of/the/folder"
4. Run "npm install" to install the packages
5. Go to "index.ts" to change the regex whose DFA is printed
6. Run "npm start" to start the program